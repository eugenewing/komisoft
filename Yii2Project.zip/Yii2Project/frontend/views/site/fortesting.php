<?php
use yii\helpers\Html;
?>

<div class="site-testing">
    <h3>
    <?= Html::a('Эффекты jQuery',['site/training1']) ?><br>
    <?= Html::a('Селекторы jQuery',['site/training2']) ?>
    </h3>
</div>